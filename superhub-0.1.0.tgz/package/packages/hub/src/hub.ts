import fs from "node:fs";
import path from "node:path";
import { randomUUID } from "node:crypto";
import Fastify, { FastifyInstance, FastifyReply, FastifyRequest } from "fastify";
import cors from "@fastify/cors";
import websocketPlugin from "@fastify/websocket";
import fastifyStatic from "@fastify/static";
import { WebSocket, type RawData } from "ws";
import {
  createDefaultContractRegistry,
  HubEnvelope,
  HubEnvelopeSchema,
  HubMessageType,
  HubTarget,
  PresencePayloadSchema,
  RpcRequestPayload,
  RpcRequestPayloadSchema,
  RpcResponsePayload,
  RpcResponsePayloadSchema,
  StatePatchPayloadSchema,
  StateSetPayloadSchema,
  SubscribePayload,
  SubscribePayloadSchema,
  hubError,
  nowEpochMs
} from "@superhub/contracts";
import { applyBackpressure } from "./backpressure.js";
import { HubConfig } from "./config.js";
import { HubLogger } from "./logger.js";
import { isIpAllowlisted } from "./network.js";
import { HubPersistence } from "./persistence.js";
import { StateStore } from "./state-store.js";

type Direction = "in" | "out" | "drop";

interface SessionQueueItem {
  raw: string;
  envelope: HubEnvelope;
  bytes: number;
  critical: boolean;
}

interface PreparedEnvelope {
  raw: string;
  bytes: number;
  shouldTrack: boolean;
}

interface SessionState {
  sessionId: string;
  socket: WebSocket;
  connectedAt: number;
  lastSeen: number;
  instanceId: string;
  clientId: string;
  serviceName?: string;
  version: string;
  provides: string[];
  consumes: string[];
  tags: string[];
  subscriptions: Map<string, SubscribePayload>;
  stateWatches: Map<string, string>;
  recentIds: Map<string, number>;
  lastDedupSweepTs: number;
  queue: SessionQueueItem[];
  queueBytes: number;
  ip: string;
  rateTokens: number;
  rateLastRefillTs: number;
}

interface PendingRpc {
  fromSessionId: string;
  startedAt: number;
  timeout: ReturnType<typeof setTimeout>;
}

interface PendingHttpRpc {
  startedAt: number;
  timeout: ReturnType<typeof setTimeout>;
  resolve: (payload: RpcResponsePayload) => void;
  reject: (error: Error) => void;
}

interface PresenceRecord {
  serviceName: string;
  clientId: string;
  instanceId: string;
  sessionId: string;
  provides: string[];
  consumes: string[];
  tags: string[];
  version: string;
  lastSeenTs: number;
  online: boolean;
}

interface InspectorRecord {
  ts: number;
  direction: Direction;
  sessionId: string;
  envelope: HubEnvelope;
  reason?: string;
}

interface Metrics {
  messagesIn: Record<HubMessageType, number>;
  messagesOut: Record<HubMessageType, number>;
  bytesIn: number;
  bytesOut: number;
  droppedMessages: number;
  reconnectCount: number;
  rpcLatenciesMs: number[];
}

interface HttpPublishBody {
  name: string;
  payload: unknown;
  target?: HubTarget;
  schemaVersion?: number;
  type?: Extract<HubMessageType, "event" | "cmd">;
}

interface HttpRpcBody {
  serviceName: string;
  method: string;
  args: unknown;
  timeoutMs?: number;
}

interface ControlDisconnectBody {
  sessionId?: string;
  clientId?: string;
}

interface ControlMuteBody {
  kind?: "service" | "topic";
  value?: string;
}

interface ControlToggleBody {
  paused?: boolean;
}

interface ControlClearQueuesBody {
  sessionId?: string;
  clientId?: string;
}

interface ControlState {
  inboundPaused: boolean;
  stateBroadcastPaused: boolean;
  mutedServices: Set<string>;
  mutedTopics: Set<string>;
}

interface ControlSnapshot {
  inboundPaused: boolean;
  stateBroadcastPaused: boolean;
  mutedServices: string[];
  mutedTopics: string[];
}

interface ControlBlock {
  code: "INBOUND_PAUSED" | "MUTED_SERVICE" | "MUTED_TOPIC" | "STATE_BROADCAST_PAUSED";
  message: string;
  details?: unknown;
}

interface PairPayload {
  url: string;
  token?: string;
}

const DASHBOARD_STREAM_EVENT_NAME = "hub.dashboard";
const DASHBOARD_STREAM_INTERVAL_MS = 500;
const DEDUP_SWEEP_INTERVAL_MS = 1000;

export interface HubRuntime {
  app: FastifyInstance;
  close: () => Promise<void>;
}

export async function createHubRuntime(config: HubConfig): Promise<HubRuntime> {
  const logger = new HubLogger(config.logging.level);
  const persistence = new HubPersistence(config.persistence);
  const stateStore = new StateStore();
  const contractRegistry = createDefaultContractRegistry();

  stateStore.loadSnapshots(persistence.loadSnapshots());

  const app = Fastify({
    logger: false,
    bodyLimit: config.limits.maxMessageSizeBytes
  });

  const sessions = new Map<string, SessionState>();
  const sessionIdsByClient = new Map<string, Set<string>>();
  const providerSessionIds = new Map<string, Set<string>>();
  const roundRobinCursor = new Map<string, number>();
  const pendingRpc = new Map<string, PendingRpc>();
  const pendingHttpRpc = new Map<string, PendingHttpRpc>();
  const presenceByServiceInstance = new Map<string, PresenceRecord>();
  const inspector: InspectorRecord[] = [];
  const messageNameCounter = new Map<string, number>();
  const clientSessionHistory = new Map<string, string>();
  const queuedSessionIds = new Set<string>();
  const controlState: ControlState = {
    inboundPaused: false,
    stateBroadcastPaused: false,
    mutedServices: new Set(),
    mutedTopics: new Set()
  };

  const metrics: Metrics = {
    messagesIn: {
      event: 0,
      cmd: 0,
      rpc_req: 0,
      rpc_res: 0,
      state_patch: 0,
      presence: 0,
      error: 0
    },
    messagesOut: {
      event: 0,
      cmd: 0,
      rpc_req: 0,
      rpc_res: 0,
      state_patch: 0,
      presence: 0,
      error: 0
    },
    bytesIn: 0,
    bytesOut: 0,
    droppedMessages: 0,
    reconnectCount: 0,
    rpcLatenciesMs: []
  };

  await app.register(cors, {
    origin: (origin: string | undefined, callback: (error: Error | null, allow: boolean) => void) => {
      if (!origin) {
        callback(null, true);
        return;
      }
      if (isCorsOriginAllowed(origin, config.cors.origins)) {
        callback(null, true);
        return;
      }
      callback(new Error("origin not allowed"), false);
    },
    allowedHeaders: config.cors.allowHeaders,
    credentials: false
  });

  await app.register(websocketPlugin, {
    options: {
      maxPayload: config.limits.maxMessageSizeBytes
    }
  });

  const hasConsoleAssets = pathExists(config.staticHosting.consoleDir);

  if (config.staticHosting.appsDir && pathExists(config.staticHosting.appsDir)) {
    await app.register(fastifyStatic, {
      root: config.staticHosting.appsDir,
      prefix: "/apps/",
      decorateReply: false
    });
  }

  app.get("/", async (_request: FastifyRequest, reply: FastifyReply) => {
    return reply.redirect("/console/");
  });

  if (hasConsoleAssets) {
    app.get("/console", async (_request: FastifyRequest, reply: FastifyReply) => {
      return reply.redirect("/console/");
    });

    app.get("/console/", async (_request: FastifyRequest, reply: FastifyReply) => {
      try {
        const served = serveStaticFromDir(reply, config.staticHosting.consoleDir, "", "index.html");
        if (!served) {
          return reply.code(404).send({ error: hubError("NOT_FOUND", "Console asset not found") });
        }
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        const isMalformedPath = message.includes("URI malformed");
        logger.error("console.asset.error", {
          wildcard: "",
          consoleDir: config.staticHosting.consoleDir,
          error: message
        });
        return reply
          .code(isMalformedPath ? 400 : 500)
          .send({ error: hubError(isMalformedPath ? "BAD_REQUEST" : "CONSOLE_ASSET_ERROR", "Failed to serve console asset") });
      }
    });

    app.get("/console/*", async (request: FastifyRequest, reply: FastifyReply) => {
      const params = request.params as Record<string, unknown> | undefined;
      const wildcard = typeof params?.["*"] === "string" ? params["*"] : "";

      try {
        const served = serveStaticFromDir(reply, config.staticHosting.consoleDir, wildcard, "index.html");
        if (!served) {
          return reply.code(404).send({ error: hubError("NOT_FOUND", "Console asset not found") });
        }
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        const isMalformedPath = message.includes("URI malformed");
        logger.error("console.asset.error", {
          wildcard,
          consoleDir: config.staticHosting.consoleDir,
          error: message
        });
        return reply
          .code(isMalformedPath ? 400 : 500)
          .send({ error: hubError(isMalformedPath ? "BAD_REQUEST" : "CONSOLE_ASSET_ERROR", "Failed to serve console asset") });
      }
    });
  }

  app.get("/api/health", async () => {
    return {
      ok: true,
      ts: nowEpochMs(),
      uptimeSec: Math.round(process.uptime()),
      sessions: sessions.size,
      services: providerSessionIds.size
    };
  });

  app.get(
    "/api/services",
    {
      preHandler: [authorizeHttp]
    },
    async () => {
      const records = Array.from(presenceByServiceInstance.values())
        .sort((a, b) => a.serviceName.localeCompare(b.serviceName) || a.instanceId.localeCompare(b.instanceId))
        .map((record) => ({
          ...record,
          health: record.online ? "online" : "offline"
        }));
      return {
        services: records
      };
    }
  );

  app.get(
    "/api/clients",
    {
      preHandler: [authorizeHttp]
    },
    async () => {
      return {
        clients: Array.from(sessions.values()).map((session) => ({
          sessionId: session.sessionId,
          clientId: session.clientId,
          serviceName: session.serviceName,
          instanceId: session.instanceId,
          ip: session.ip,
          connectedAt: session.connectedAt,
          lastSeen: session.lastSeen,
          provides: session.provides,
          consumes: session.consumes,
          tags: session.tags
        }))
      };
    }
  );

  app.get(
    "/api/topics",
    {
      preHandler: [authorizeHttp]
    },
    async () => {
      return {
        topics: Array.from(messageNameCounter.entries())
          .map(([name, count]) => ({ name, count }))
          .sort((a, b) => b.count - a.count)
      };
    }
  );

  app.get(
    "/api/messages",
    {
      preHandler: [authorizeHttp]
    },
    async () => {
      return {
        messages: inspector
      };
    }
  );

  app.get(
    "/api/config",
    {
      preHandler: [authorizeHttp]
    },
    async () => {
      return {
        domain: config.domain,
        listen: config.listen,
        cors: config.cors,
        limits: config.limits,
        validation: config.validation,
        persistence: {
          enabled: config.persistence.enabled,
          auditEnabled: config.persistence.auditEnabled,
          sqlitePath: config.persistence.sqlitePath
        },
        security: {
          tokenConfigured: Boolean(config.security.token),
          pairingEnabled: config.security.pairingEnabled,
          allowlistSubnets: config.security.allowlistSubnets
        }
      };
    }
  );

  app.get(
    "/api/metrics",
    {
      preHandler: [authorizeHttp]
    },
    async () => {
      return metricsSnapshot();
    }
  );

  app.get(
    "/api/diagnostics",
    {
      preHandler: [authorizeHttp]
    },
    async () => {
      return diagnosticsSnapshot();
    }
  );

  app.get(
    "/api/control",
    {
      preHandler: [authorizeHttp]
    },
    async () => {
      return {
        control: controlSnapshot()
      };
    }
  );

  app.post(
    "/api/control/disconnect",
    {
      preHandler: [authorizeHttp]
    },
    async (request: FastifyRequest, reply: FastifyReply) => {
      const body = (request.body ?? {}) as ControlDisconnectBody;
      const sessionId = normalizeControlValue(body.sessionId);
      const clientId = normalizeControlValue(body.clientId);

      if (!sessionId && !clientId) {
        return reply.code(400).send({ error: hubError("INVALID_REQUEST", "sessionId or clientId is required") });
      }

      const targets: SessionState[] = sessionId
        ? [sessions.get(sessionId)].filter((session): session is SessionState => Boolean(session))
        : findSessionsByClientId(clientId!);

      if (targets.length === 0) {
        return reply.code(404).send({ error: hubError("NOT_FOUND", "No matching session found") });
      }

      for (const session of targets) {
        session.socket.close(1008, "Disconnected by control plane");
      }

      logger.warn("control.disconnect", {
        sessionId,
        clientId,
        disconnected: targets.map((session) => session.sessionId)
      });

      return {
        ok: true,
        disconnected: targets.map((session) => ({
          sessionId: session.sessionId,
          clientId: session.clientId,
          serviceName: session.serviceName
        }))
      };
    }
  );

  app.post(
    "/api/control/mute",
    {
      preHandler: [authorizeHttp]
    },
    async (request: FastifyRequest, reply: FastifyReply) => {
      const body = (request.body ?? {}) as ControlMuteBody;
      const kind = body.kind;
      const value = normalizeControlValue(body.value);

      if (!kind || (kind !== "service" && kind !== "topic")) {
        return reply.code(400).send({ error: hubError("INVALID_REQUEST", "kind must be 'service' or 'topic'") });
      }
      if (!value) {
        return reply.code(400).send({ error: hubError("INVALID_REQUEST", "value is required") });
      }

      if (kind === "service") {
        controlState.mutedServices.add(value);
      } else {
        controlState.mutedTopics.add(value);
      }

      logger.warn("control.mute", {
        kind,
        value,
        control: controlSnapshot()
      });

      return {
        ok: true,
        control: controlSnapshot()
      };
    }
  );

  app.post(
    "/api/control/unmute",
    {
      preHandler: [authorizeHttp]
    },
    async (request: FastifyRequest, reply: FastifyReply) => {
      const body = (request.body ?? {}) as ControlMuteBody;
      const kind = body.kind;
      const value = normalizeControlValue(body.value);

      if (!kind || (kind !== "service" && kind !== "topic")) {
        return reply.code(400).send({ error: hubError("INVALID_REQUEST", "kind must be 'service' or 'topic'") });
      }
      if (!value) {
        return reply.code(400).send({ error: hubError("INVALID_REQUEST", "value is required") });
      }

      if (kind === "service") {
        controlState.mutedServices.delete(value);
      } else {
        controlState.mutedTopics.delete(value);
      }

      logger.warn("control.unmute", {
        kind,
        value,
        control: controlSnapshot()
      });

      return {
        ok: true,
        control: controlSnapshot()
      };
    }
  );

  app.post(
    "/api/control/inbound",
    {
      preHandler: [authorizeHttp]
    },
    async (request: FastifyRequest, reply: FastifyReply) => {
      const body = (request.body ?? {}) as ControlToggleBody;
      if (typeof body.paused !== "boolean") {
        return reply.code(400).send({ error: hubError("INVALID_REQUEST", "paused boolean is required") });
      }

      controlState.inboundPaused = body.paused;
      logger.warn("control.inbound", {
        paused: controlState.inboundPaused
      });

      return {
        ok: true,
        control: controlSnapshot()
      };
    }
  );

  app.post(
    "/api/control/state-broadcast",
    {
      preHandler: [authorizeHttp]
    },
    async (request: FastifyRequest, reply: FastifyReply) => {
      const body = (request.body ?? {}) as ControlToggleBody;
      if (typeof body.paused !== "boolean") {
        return reply.code(400).send({ error: hubError("INVALID_REQUEST", "paused boolean is required") });
      }

      controlState.stateBroadcastPaused = body.paused;
      logger.warn("control.state_broadcast", {
        paused: controlState.stateBroadcastPaused
      });

      return {
        ok: true,
        control: controlSnapshot()
      };
    }
  );

  app.post(
    "/api/control/clear-queues",
    {
      preHandler: [authorizeHttp]
    },
    async (request: FastifyRequest, reply: FastifyReply) => {
      const body = (request.body ?? {}) as ControlClearQueuesBody;
      const sessionId = normalizeControlValue(body.sessionId);
      const clientId = normalizeControlValue(body.clientId);

      const targets: SessionState[] = sessionId
        ? [sessions.get(sessionId)].filter((session): session is SessionState => Boolean(session))
        : clientId
        ? findSessionsByClientId(clientId)
        : Array.from(sessions.values());

      if (targets.length === 0) {
        return reply.code(404).send({ error: hubError("NOT_FOUND", "No matching session found") });
      }

      let clearedMessages = 0;
      let clearedBytes = 0;
      for (const session of targets) {
        const cleared = clearSessionQueue(session);
        clearedMessages += cleared.messages;
        clearedBytes += cleared.bytes;
      }

      logger.warn("control.clear_queues", {
        sessionId,
        clientId,
        targets: targets.length,
        clearedMessages,
        clearedBytes
      });

      return {
        ok: true,
        targets: targets.length,
        clearedMessages,
        clearedBytes
      };
    }
  );

  app.get(
    "/api/state",
    {
      preHandler: [authorizeHttp]
    },
    async (request: FastifyRequest) => {
      const query = request.query as { path?: string; prefix?: string };
      if (query.path) {
        return { path: query.path, value: stateStore.get(query.path) };
      }

      return {
        entries: stateStore.list(query.prefix)
      };
    }
  );

  app.post(
    "/api/publish",
    {
      preHandler: [authorizeHttp]
    },
    async (request: FastifyRequest, reply: FastifyReply) => {
      const body = request.body as HttpPublishBody;

      if (!body?.name) {
        return reply.code(400).send({ error: hubError("INVALID_REQUEST", "name is required") });
      }

      if (controlState.inboundPaused) {
        return reply.code(503).send({ error: hubError("INBOUND_PAUSED", "Inbound traffic is paused by control plane") });
      }

      const envelope = createEnvelope({
        type: body.type ?? "event",
        name: body.name,
        source: {
          clientId: "http-api",
          serviceName: "hub"
        },
        target: body.target ?? "*",
        payload: body.payload,
        schemaVersion: body.schemaVersion ?? 1
      });

      routeMessage(null, envelope);

      return { ok: true, id: envelope.id };
    }
  );

  app.post(
    "/api/rpc",
    {
      preHandler: [authorizeHttp]
    },
    async (request: FastifyRequest, reply: FastifyReply) => {
      const body = request.body as HttpRpcBody;
      if (!body?.serviceName || !body?.method) {
        return reply.code(400).send({ error: hubError("INVALID_REQUEST", "serviceName and method are required") });
      }

      if (controlState.inboundPaused) {
        return reply.code(503).send({ error: hubError("INBOUND_PAUSED", "Inbound traffic is paused by control plane") });
      }

      const correlationId = randomUUID();
      const timeoutMs = Math.min(Math.max(body.timeoutMs ?? 15000, 100), 120000);

      const envelope = createEnvelope({
        type: "rpc_req",
        name: body.method,
        source: {
          clientId: "http-api",
          serviceName: "hub"
        },
        target: { serviceName: body.serviceName },
        correlationId,
        schemaVersion: 1,
        payload: {
          method: body.method,
          args: body.args,
          timeoutMs
        } satisfies RpcRequestPayload
      });

      const response = await new Promise<RpcResponsePayload>((resolve, reject) => {
        const timeout = setTimeout(() => {
          pendingHttpRpc.delete(correlationId);
          reject(new Error(`RPC timeout for ${body.serviceName}.${body.method}`));
        }, timeoutMs);

        pendingHttpRpc.set(correlationId, {
          startedAt: nowEpochMs(),
          timeout,
          resolve,
          reject
        });

        routeRpcRequest(null, envelope);
      }).catch((error) => {
        return {
          ok: false,
          error: hubError("RPC_TIMEOUT", error instanceof Error ? error.message : "RPC timeout")
        } satisfies RpcResponsePayload;
      });

      return { correlationId, response };
    }
  );

  app.get("/console/pair", async (request: FastifyRequest, reply: FastifyReply) => {
    if (!config.security.pairingEnabled) {
      return reply.code(404).send("Pairing is disabled");
    }

    const remoteIp = request.ip;
    if (!isIpAllowlisted(remoteIp, config.security.allowlistSubnets)) {
      return reply.code(403).send("Forbidden");
    }

    const payload: PairPayload = {
      url: `https://${config.domain}`,
      token: config.security.token
    };

    const serialized = JSON.stringify(payload);
    const qrDataUrl = await generateQrDataUrl(serialized);
    const hasQr = Boolean(qrDataUrl);

    return reply
      .type("text/html; charset=utf-8")
      .send(`<!doctype html>
<html>
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <title>SuperHub Pairing</title>
    <style>
      body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; max-width: 760px; margin: 40px auto; padding: 0 16px; }
      code, pre { background: #f3f3f3; padding: 4px 6px; border-radius: 6px; }
      pre { white-space: pre-wrap; }
      .pill { display: inline-block; padding: 4px 8px; border-radius: 999px; background: #111; color: #fff; }
      .pair-grid { display: grid; grid-template-columns: 300px 1fr; gap: 16px; align-items: start; margin: 16px 0; }
      .qr { border: 1px solid #ddd; border-radius: 10px; width: 280px; height: 280px; background: #fff; display: flex; align-items: center; justify-content: center; }
      .warn { padding: 10px; border-radius: 8px; background: #fff4e5; border: 1px solid #f0ca91; color: #6d4700; }
      button { border: 1px solid #222; background: #fff; padding: 8px 12px; border-radius: 8px; cursor: pointer; }
      @media (max-width: 760px) { .pair-grid { grid-template-columns: 1fr; } }
    </style>
  </head>
  <body>
    <h1>Pairing SuperHub</h1>
    <p class="pill">${escapeHtml(config.domain)}</p>
    <p>Scanne le QR code depuis ton app cliente, ou copie le JSON manuellement.</p>
    <div class="pair-grid">
      <div class="qr">
        ${
          hasQr
            ? `<img src="${qrDataUrl}" width="280" height="280" alt="QR code pairing SuperHub" />`
            : `<div class="warn">QR indisponible: installe la dependance <code>qrcode</code> puis redemarre le hub.</div>`
        }
      </div>
      <div>
        <button id="copy-btn">Copier le JSON</button>
        <pre id="payload">${escapeHtml(serialized)}</pre>
      </div>
    </div>
    <script>
      document.getElementById("copy-btn")?.addEventListener("click", async () => {
        const text = document.getElementById("payload")?.textContent || "";
        try {
          await navigator.clipboard.writeText(text);
          alert("Payload copie");
        } catch {
          alert("Impossible de copier automatiquement");
        }
      });
    </script>
  </body>
</html>`);
  });

  app.get(
    "/ws",
    {
      websocket: true
    },
    (socket: WebSocket, request: FastifyRequest) => {
      const tokenResult = authorizeTokenForRequest(request);
      if (!tokenResult.ok) {
        logger.warn("ws.unauthorized", {
          ip: request.ip,
          reason: tokenResult.reason
        });
        socket.send(JSON.stringify(errorEnvelope("AUTH_REQUIRED", tokenResult.reason, null, "*")));
        socket.close(1008, tokenResult.reason);
        return;
      }

      if (!isIpAllowlisted(request.ip, config.security.allowlistSubnets)) {
        logger.warn("ws.forbidden.ip", {
          ip: request.ip,
          allowlist: config.security.allowlistSubnets
        });
        socket.send(
          JSON.stringify(
            errorEnvelope("FORBIDDEN", "IP is not allowlisted", null, {
              ip: request.ip
            })
          )
        );
        socket.close(1008, "Forbidden");
        return;
      }

      const sessionId = randomUUID();
      const now = nowEpochMs();

      const session: SessionState = {
        sessionId,
        socket,
        connectedAt: now,
        lastSeen: now,
        instanceId: randomUUID(),
        clientId: `anonymous-${sessionId.slice(0, 8)}`,
        version: "0.0.0",
        provides: [],
        consumes: [],
        tags: [],
        subscriptions: new Map(),
        stateWatches: new Map(),
        recentIds: new Map(),
        lastDedupSweepTs: now,
        queue: [],
        queueBytes: 0,
        ip: request.ip,
        rateTokens: Math.max(0, config.limits.rateLimitPerMinute),
        rateLastRefillTs: now
      };

      sessions.set(session.sessionId, session);

      logger.info("ws.connected", {
        sessionId: session.sessionId,
        clientId: session.clientId,
        ip: session.ip
      });

      socket.on("pong", () => {
        session.lastSeen = nowEpochMs();
      });

      socket.on("message", (raw: RawData) => {
        session.lastSeen = nowEpochMs();
        handleSocketMessage(session, raw.toString("utf8"));
      });

      socket.on("close", () => {
        onSessionClosed(session.sessionId);
      });

      socket.on("error", (error: Error) => {
        logger.warn("ws.error", {
          sessionId: session.sessionId,
          clientId: session.clientId,
          error: error.message
        });
      });
    }
  );

  const heartbeatTimer = setInterval(() => {
    const now = nowEpochMs();

    for (const session of sessions.values()) {
      if (now - session.lastSeen > config.limits.heartbeatTimeoutMs) {
        logger.warn("ws.timeout", {
          sessionId: session.sessionId,
          clientId: session.clientId
        });
        session.socket.close(1001, "Heartbeat timeout");
        continue;
      }

      if (session.socket.readyState === WebSocket.OPEN) {
        session.socket.ping();
      }
    }
  }, config.limits.heartbeatIntervalMs);

  const queueFlushTimer = setInterval(() => {
    for (const sessionId of queuedSessionIds) {
      const session = sessions.get(sessionId);
      if (!session) {
        queuedSessionIds.delete(sessionId);
        continue;
      }
      flushSessionQueue(session);
      if (session.queue.length === 0 || session.socket.readyState !== WebSocket.OPEN) {
        queuedSessionIds.delete(sessionId);
      }
    }
  }, 50);

  const retentionTimer = setInterval(() => {
    persistence.vacuumAudit(nowEpochMs());
  }, 60 * 60 * 1000);

  const dashboardStreamTimer = setInterval(() => {
    pushDashboardSnapshot();
  }, DASHBOARD_STREAM_INTERVAL_MS);

  app.addHook("onClose", async () => {
    clearInterval(heartbeatTimer);
    clearInterval(queueFlushTimer);
    clearInterval(retentionTimer);
    clearInterval(dashboardStreamTimer);

    for (const pending of pendingRpc.values()) {
      clearTimeout(pending.timeout);
    }
    pendingRpc.clear();

    for (const pending of pendingHttpRpc.values()) {
      clearTimeout(pending.timeout);
      pending.reject(new Error("Hub shutting down"));
    }
    pendingHttpRpc.clear();

    persistence.close();
  });

  function metricsSnapshot(): {
    messagesIn: Metrics["messagesIn"];
    messagesOut: Metrics["messagesOut"];
    bytesIn: number;
    bytesOut: number;
    droppedMessages: number;
    reconnectCount: number;
    rpcLatencyAvgMs: number;
    rpcLatencyP95Ms: number;
  } {
    const latencies = [...metrics.rpcLatenciesMs].sort((a, b) => a - b);
    const mean = latencies.length ? latencies.reduce((sum, value) => sum + value, 0) / latencies.length : 0;
    const p95 = percentile(latencies, 95);

    return {
      messagesIn: metrics.messagesIn,
      messagesOut: metrics.messagesOut,
      bytesIn: metrics.bytesIn,
      bytesOut: metrics.bytesOut,
      droppedMessages: metrics.droppedMessages,
      reconnectCount: metrics.reconnectCount,
      rpcLatencyAvgMs: Number(mean.toFixed(2)),
      rpcLatencyP95Ms: Number(p95.toFixed(2))
    };
  }

  function hasSubscribersFor(messageName: string): boolean {
    for (const session of sessions.values()) {
      if (matchesSubscription(session, messageName)) {
        return true;
      }
    }
    return false;
  }

  function dashboardSnapshotPayload(): Record<string, unknown> {
    return {
      ts: nowEpochMs(),
      health: {
        ok: true,
        ts: nowEpochMs(),
        uptimeSec: Math.round(process.uptime()),
        sessions: sessions.size,
        services: providerSessionIds.size
      },
      metrics: metricsSnapshot(),
      diagnostics: diagnosticsSnapshot(),
      services: Array.from(presenceByServiceInstance.values())
        .sort((a, b) => a.serviceName.localeCompare(b.serviceName) || a.instanceId.localeCompare(b.instanceId))
        .map((record) => ({
          ...record,
          health: record.online ? "online" : "offline"
        })),
      clients: Array.from(sessions.values()).map((session) => ({
        sessionId: session.sessionId,
        clientId: session.clientId,
        serviceName: session.serviceName,
        instanceId: session.instanceId,
        ip: session.ip,
        connectedAt: session.connectedAt,
        lastSeen: session.lastSeen,
        provides: session.provides,
        consumes: session.consumes,
        tags: session.tags
      }))
    };
  }

  function diagnosticsSnapshot(): {
    ts: number;
    uptimeSec: number;
    routing: {
      pendingWsRpc: number;
      pendingHttpRpc: number;
      activeProviders: number;
    };
    sessions: {
      total: number;
      byClient: number;
      subscriptions: number;
      stateWatches: number;
    };
    queues: {
      totalMessages: number;
      totalBytes: number;
      maxMessagesInSession: number;
      queuedSessions: number;
    };
    inspector: {
      bufferedMessages: number;
    };
    control: ControlSnapshot;
    config: {
      domain: string;
      listen: HubConfig["listen"];
      limits: HubConfig["limits"];
      validation: HubConfig["validation"];
      security: {
        tokenConfigured: boolean;
        allowlistSubnets: string[];
      };
    };
  } {
    const queueDepths = Array.from(sessions.values()).map((session) => session.queue.length);
    const totalQueuedMessages = queueDepths.reduce((sum, value) => sum + value, 0);
    const maxQueuedMessages = queueDepths.length ? Math.max(...queueDepths) : 0;
    const totalQueuedBytes = Array.from(sessions.values()).reduce((sum, session) => sum + session.queueBytes, 0);
    const totalSubscriptions = Array.from(sessions.values()).reduce((sum, session) => sum + session.subscriptions.size, 0);
    const totalWatches = Array.from(sessions.values()).reduce((sum, session) => sum + session.stateWatches.size, 0);

    return {
      ts: nowEpochMs(),
      uptimeSec: Math.round(process.uptime()),
      routing: {
        pendingWsRpc: pendingRpc.size,
        pendingHttpRpc: pendingHttpRpc.size,
        activeProviders: providerSessionIds.size
      },
      sessions: {
        total: sessions.size,
        byClient: sessionIdsByClient.size,
        subscriptions: totalSubscriptions,
        stateWatches: totalWatches
      },
      queues: {
        totalMessages: totalQueuedMessages,
        totalBytes: totalQueuedBytes,
        maxMessagesInSession: maxQueuedMessages,
        queuedSessions: queuedSessionIds.size
      },
      inspector: {
        bufferedMessages: inspector.length
      },
      control: controlSnapshot(),
      config: {
        domain: config.domain,
        listen: config.listen,
        limits: config.limits,
        validation: config.validation,
        security: {
          tokenConfigured: Boolean(config.security.token),
          allowlistSubnets: config.security.allowlistSubnets
        }
      }
    };
  }

  function controlSnapshot(): ControlSnapshot {
    return {
      inboundPaused: controlState.inboundPaused,
      stateBroadcastPaused: controlState.stateBroadcastPaused,
      mutedServices: Array.from(controlState.mutedServices).sort(),
      mutedTopics: Array.from(controlState.mutedTopics).sort()
    };
  }

  function pushDashboardSnapshot(): void {
    if (!hasSubscribersFor(DASHBOARD_STREAM_EVENT_NAME)) {
      return;
    }

    const envelope = createEnvelope({
      type: "event",
      name: DASHBOARD_STREAM_EVENT_NAME,
      source: {
        clientId: "hub",
        serviceName: "hub"
      },
      target: "*",
      schemaVersion: 1,
      payload: dashboardSnapshotPayload()
    });

    routePublishLike(null, envelope);
  }

  function authorizeHttp(request: FastifyRequest, reply: FastifyReply, done: (error?: Error) => void): void {
    if (!isIpAllowlisted(request.ip, config.security.allowlistSubnets)) {
      logger.warn("http.forbidden.ip", {
        method: request.method,
        url: request.url,
        ip: request.ip
      });
      reply.code(403).send({ error: hubError("FORBIDDEN", "IP is not allowlisted") });
      return done(new Error("forbidden"));
    }

    const result = authorizeTokenForRequest(request);
    if (!result.ok) {
      logger.warn("http.unauthorized", {
        method: request.method,
        url: request.url,
        ip: request.ip,
        reason: result.reason
      });
      reply.code(401).send({ error: hubError("AUTH_REQUIRED", result.reason) });
      return done(new Error("unauthorized"));
    }

    done();
  }

  function authorizeTokenForRequest(request: Pick<FastifyRequest, "headers" | "url">): { ok: true } | { ok: false; reason: string } {
    if (!config.security.token) {
      return { ok: true };
    }

    const fromHeader = request.headers["x-hub-token"];
    const headerToken = Array.isArray(fromHeader) ? fromHeader[0] : fromHeader;

    const parsed = new URL(request.url, "http://localhost");
    const queryToken = parsed.searchParams.get("token") ?? undefined;

    if (headerToken === config.security.token || queryToken === config.security.token) {
      return { ok: true };
    }

    return { ok: false, reason: "Missing or invalid hub token" };
  }

  function normalizeControlValue(value: unknown): string | null {
    if (typeof value !== "string") {
      return null;
    }
    const trimmed = value.trim();
    return trimmed.length > 0 ? trimmed : null;
  }

  function handleSocketMessage(session: SessionState, raw: string): void {
    const rawBytes = Buffer.byteLength(raw, "utf8");
    metrics.bytesIn += rawBytes;

    if (!incrementSessionRate(session)) {
      logger.warn("ws.rate_limit", {
        sessionId: session.sessionId,
        clientId: session.clientId,
        ip: session.ip,
        rateLimitPerMinute: config.limits.rateLimitPerMinute
      });
      const response = errorEnvelope("RATE_LIMIT", "Rate limit exceeded", session.clientId, {
        clientId: session.clientId,
        rateLimitPerMinute: config.limits.rateLimitPerMinute
      });
      enqueueForSession(session, response, true);
      return;
    }

    if (rawBytes > config.limits.maxMessageSizeBytes) {
      logger.warn("ws.message_too_large", {
        sessionId: session.sessionId,
        clientId: session.clientId,
        size: rawBytes,
        max: config.limits.maxMessageSizeBytes
      });
      const response = errorEnvelope("MESSAGE_TOO_LARGE", "Message exceeds max payload size", session.clientId, {
        clientId: session.clientId
      });
      enqueueForSession(session, response, true);
      return;
    }

    let parsed: unknown;
    try {
      parsed = JSON.parse(raw);
    } catch {
      logger.warn("ws.invalid_json", {
        sessionId: session.sessionId,
        clientId: session.clientId
      });
      const response = errorEnvelope("INVALID_JSON", "Message is not valid JSON", session.clientId, { clientId: session.clientId });
      enqueueForSession(session, response, true);
      return;
    }

    const envelopeResult = HubEnvelopeSchema.safeParse(parsed);
    if (!envelopeResult.success) {
      logger.warn("ws.invalid_envelope", {
        sessionId: session.sessionId,
        clientId: session.clientId,
        issues: envelopeResult.error.issues
      });
      const response = errorEnvelope("INVALID_ENVELOPE", "Message does not match envelope schema", session.clientId, {
        clientId: session.clientId,
        issues: envelopeResult.error.issues
      });
      enqueueForSession(session, response, true);
      return;
    }

    const envelope = envelopeResult.data;

    if (isDuplicateMessage(session, envelope.id)) {
      return;
    }

    if (controlState.inboundPaused && envelope.type !== "presence") {
      metrics.droppedMessages += 1;
      logger.warn("control.inbound.drop", {
        sessionId: session.sessionId,
        clientId: session.clientId,
        type: envelope.type,
        name: envelope.name
      });
      if (shouldTrackInternalEnvelope(envelope)) {
        pushInspector("drop", session.sessionId, envelope, "inbound paused");
      }
      enqueueForSession(
        session,
        errorEnvelope("INBOUND_PAUSED", "Inbound traffic is paused by control plane", session.clientId, {
          type: envelope.type,
          name: envelope.name
        }),
        true
      );
      return;
    }

    metrics.messagesIn[envelope.type] += 1;
    bumpTopic(envelope.name);

    pushInspector("in", session.sessionId, envelope);

    const contractPayload = payloadForContractValidation(envelope);
    if (contractPayload.shouldValidate) {
      const contractValidation = contractRegistry.validate(envelope.name, envelope.schemaVersion, contractPayload.payload);
      if (!contractValidation.ok) {
        const details = {
          name: envelope.name,
          schemaVersion: envelope.schemaVersion,
          issues: contractValidation.issues
        };

        if (config.validation.mode === "reject") {
          logger.warn("payload.validation.reject", {
            sessionId: session.sessionId,
            clientId: session.clientId,
            ...details
          });
          const response = errorEnvelope("PAYLOAD_VALIDATION_FAILED", "Payload validation failed", session.clientId, details, envelope.correlationId);
          enqueueForSession(session, response, true);
          return;
        }

        logger.warn("payload.validation.warn", {
          sessionId: session.sessionId,
          clientId: session.clientId,
          ...details
        });
      }
    }

    routeMessage(session, envelope);
  }

  function routeMessage(session: SessionState | null, envelope: HubEnvelope): void {
    switch (envelope.type) {
      case "presence":
        if (!session) {
          return;
        }
        handlePresence(session, envelope);
        return;
      case "event":
      case "cmd":
        if (envelope.name === "subscribe") {
          if (!session) {
            return;
          }
          handleSubscribe(session, envelope);
          return;
        }
        if (envelope.name === "unsubscribe") {
          if (!session) {
            return;
          }
          handleUnsubscribe(session, envelope);
          return;
        }
        if (envelope.name === "state_set") {
          if (!session) {
            return;
          }
          handleStateSet(session, envelope);
          return;
        }
        if (envelope.name === "state_patch") {
          if (!session) {
            return;
          }
          handleStatePatch(session, envelope);
          return;
        }
        if (envelope.name === "state_watch") {
          if (!session) {
            return;
          }
          handleStateWatch(session, envelope);
          return;
        }
        if (envelope.name === "state_unwatch") {
          if (!session) {
            return;
          }
          handleStateUnwatch(session, envelope);
          return;
        }

        routePublishLike(session, envelope);
        return;
      case "rpc_req":
        routeRpcRequest(session, envelope);
        return;
      case "rpc_res":
        routeRpcResponse(session, envelope);
        return;
      case "state_patch":
        if (!session) {
          return;
        }
        routePublishLike(session, envelope);
        return;
      case "error":
        logger.warn("client.error", {
          sessionId: session?.sessionId,
          clientId: session?.clientId,
          payload: envelope.payload
        });
        return;
      default:
        return;
    }
  }

  function handlePresence(session: SessionState, envelope: HubEnvelope): void {
    const parsed = PresencePayloadSchema.safeParse(envelope.payload);
    if (!parsed.success) {
      enqueueForSession(
        session,
        errorEnvelope("INVALID_PRESENCE", "presence payload is invalid", session.clientId, parsed.error.issues, envelope.correlationId),
        true
      );
      return;
    }

    const payload = parsed.data;

    if (clientSessionHistory.has(payload.clientId) && clientSessionHistory.get(payload.clientId) !== session.sessionId) {
      metrics.reconnectCount += 1;
    }
    clientSessionHistory.set(payload.clientId, session.sessionId);

    detachSessionFromIndexes(session);

    session.clientId = payload.clientId;
    session.serviceName = payload.serviceName;
    session.version = payload.version;
    session.provides = payload.provides;
    session.consumes = payload.consumes;
    session.tags = payload.tags;
    session.lastSeen = nowEpochMs();

    if (!sessionIdsByClient.has(session.clientId)) {
      sessionIdsByClient.set(session.clientId, new Set());
    }
    sessionIdsByClient.get(session.clientId)!.add(session.sessionId);

    if (session.serviceName) {
      if (!providerSessionIds.has(session.serviceName)) {
        providerSessionIds.set(session.serviceName, new Set());
      }
      providerSessionIds.get(session.serviceName)!.add(session.sessionId);

      const record: PresenceRecord = {
        serviceName: session.serviceName,
        clientId: session.clientId,
        instanceId: session.instanceId,
        sessionId: session.sessionId,
        provides: session.provides,
        consumes: session.consumes,
        tags: session.tags,
        version: session.version,
        lastSeenTs: session.lastSeen,
        online: true
      };

      presenceByServiceInstance.set(`${record.serviceName}::${record.instanceId}`, record);
      persistence.upsertPresence(record);
    }

    logger.info("presence.upsert", {
      sessionId: session.sessionId,
      clientId: session.clientId,
      serviceName: session.serviceName,
      provides: session.provides,
      consumes: session.consumes,
      tags: session.tags
    });
  }

  function handleSubscribe(session: SessionState, envelope: HubEnvelope): void {
    const payload = envelope.payload as { subscriptionId?: string; names?: string[]; namePrefix?: string };
    const subscriptionId = typeof payload.subscriptionId === "string" ? payload.subscriptionId : randomUUID();

    const parsed = SubscribePayloadSchema.safeParse({ names: payload.names, namePrefix: payload.namePrefix });
    if (!parsed.success) {
      enqueueForSession(
        session,
        errorEnvelope("INVALID_SUBSCRIBE", "subscribe payload invalid", session.clientId, parsed.error.issues, envelope.correlationId),
        true
      );
      return;
    }

    session.subscriptions.set(subscriptionId, parsed.data);

    if (config.logging.routeDebug) {
      logger.debug("subscription.added", {
        sessionId: session.sessionId,
        clientId: session.clientId,
        subscriptionId,
        filter: parsed.data
      });
    }
  }

  function handleUnsubscribe(session: SessionState, envelope: HubEnvelope): void {
    const payload = envelope.payload as { subscriptionId?: string };
    if (!payload.subscriptionId) {
      return;
    }

    session.subscriptions.delete(payload.subscriptionId);
  }

  function handleStateSet(session: SessionState, envelope: HubEnvelope): void {
    const parsed = StateSetPayloadSchema.safeParse(envelope.payload);
    if (!parsed.success) {
      enqueueForSession(
        session,
        errorEnvelope("INVALID_STATE_SET", "state_set payload invalid", session.clientId, parsed.error.issues, envelope.correlationId),
        true
      );
      return;
    }

    const mutation = stateStore.set(parsed.data.path, parsed.data.value);
    persistence.saveStateSnapshot(mutation.path, mutation.value, nowEpochMs());
    broadcastStatePatch(mutation.path, mutation.value, envelope.source);
  }

  function handleStatePatch(session: SessionState, envelope: HubEnvelope): void {
    const parsed = StatePatchPayloadSchema.safeParse(envelope.payload);
    if (!parsed.success) {
      enqueueForSession(
        session,
        errorEnvelope("INVALID_STATE_PATCH", "state_patch payload invalid", session.clientId, parsed.error.issues, envelope.correlationId),
        true
      );
      return;
    }

    const mutation = stateStore.patch(parsed.data.path, parsed.data.patch);
    persistence.saveStateSnapshot(mutation.path, mutation.value, nowEpochMs());
    broadcastStatePatch(mutation.path, mutation.value, envelope.source);
  }

  function handleStateWatch(session: SessionState, envelope: HubEnvelope): void {
    const payload = envelope.payload as { watchId?: string; prefix?: string };
    if (!payload.watchId || !payload.prefix) {
      enqueueForSession(
        session,
        errorEnvelope("INVALID_STATE_WATCH", "state_watch requires watchId and prefix", session.clientId, envelope.payload, envelope.correlationId),
        true
      );
      return;
    }

    session.stateWatches.set(payload.watchId, normalizeStatePath(payload.prefix));
  }

  function handleStateUnwatch(session: SessionState, envelope: HubEnvelope): void {
    const payload = envelope.payload as { watchId?: string };
    if (!payload.watchId) {
      return;
    }
    session.stateWatches.delete(payload.watchId);
  }

  function routePublishLike(sourceSession: SessionState | null, envelope: HubEnvelope): void {
    const controlBlock = controlBlockForEnvelope(envelope);
    if (controlBlock) {
      trackControlDrop(sourceSession?.sessionId ?? "control", envelope, controlBlock.message);
      return;
    }

    const recipients = resolveRecipientsForPublish(envelope, sourceSession?.sessionId);
    if (recipients.length === 0) {
      return;
    }
    const prepared = recipients.length > 1 ? prepareEnvelopeForSend(envelope) : null;
    for (const recipient of recipients) {
      enqueueForSession(recipient, envelope, false, prepared);
    }
  }

  function routeRpcRequest(sourceSession: SessionState | null, envelope: HubEnvelope): void {
    const payload = RpcRequestPayloadSchema.safeParse(envelope.payload);
    if (!payload.success) {
      logger.warn("rpc.invalid_request", {
        sessionId: sourceSession?.sessionId,
        clientId: sourceSession?.clientId,
        issues: payload.error.issues
      });
      if (sourceSession) {
        enqueueForSession(
          sourceSession,
          createRpcResponseEnvelope(
            envelope,
            {
              ok: false,
              error: hubError("INVALID_RPC", "Invalid rpc_req payload", payload.error.issues)
            },
            sourceSession.clientId
          ),
          true
        );
      }
      return;
    }

    const method = payload.data.method;

    if (isHubTarget(envelope.target)) {
      handleHubRpc(sourceSession, envelope, method, payload.data);
      return;
    }

    const controlBlock = controlBlockForEnvelope(envelope);
    if (controlBlock) {
      trackControlDrop(sourceSession?.sessionId ?? "control", envelope, controlBlock.message);
      const blockedResponse: RpcResponsePayload = {
        ok: false,
        error: hubError(controlBlock.code, controlBlock.message, controlBlock.details)
      };

      if (sourceSession) {
        enqueueForSession(sourceSession, createRpcResponseEnvelope(envelope, blockedResponse, sourceSession.clientId), true);
      } else if (envelope.correlationId && pendingHttpRpc.has(envelope.correlationId)) {
        const pending = pendingHttpRpc.get(envelope.correlationId)!;
        clearTimeout(pending.timeout);
        pendingHttpRpc.delete(envelope.correlationId);
        pending.resolve(blockedResponse);
      }
      return;
    }

    const targetService = extractServiceTarget(envelope.target);
    if (!targetService) {
      logger.warn("rpc.target_missing", {
        sessionId: sourceSession?.sessionId,
        clientId: sourceSession?.clientId,
        envelopeId: envelope.id
      });
      if (sourceSession) {
        enqueueForSession(
          sourceSession,
          createRpcResponseEnvelope(
            envelope,
            {
              ok: false,
              error: hubError("RPC_TARGET_REQUIRED", "rpc_req requires target serviceName")
            },
            sourceSession.clientId
          ),
          true
        );
      }
      return;
    }

    const provider = pickProviderSession(targetService);
    if (!provider) {
      logger.warn("rpc.service_unavailable", {
        sessionId: sourceSession?.sessionId,
        clientId: sourceSession?.clientId,
        targetService,
        method
      });
      if (sourceSession) {
        enqueueForSession(
          sourceSession,
          createRpcResponseEnvelope(
            envelope,
            {
              ok: false,
              error: hubError("SERVICE_UNAVAILABLE", `No provider for service ${targetService}`)
            },
            sourceSession.clientId
          ),
          true
        );
      } else if (envelope.correlationId && pendingHttpRpc.has(envelope.correlationId)) {
        const pending = pendingHttpRpc.get(envelope.correlationId)!;
        clearTimeout(pending.timeout);
        pendingHttpRpc.delete(envelope.correlationId);
        pending.resolve({
          ok: false,
          error: hubError("SERVICE_UNAVAILABLE", `No provider for service ${targetService}`)
        });
      }
      return;
    }

    if (!envelope.correlationId) {
      logger.warn("rpc.correlation_missing", {
        sessionId: sourceSession?.sessionId,
        clientId: sourceSession?.clientId,
        targetService,
        method
      });
      if (sourceSession) {
        enqueueForSession(
          sourceSession,
          errorEnvelope("RPC_CORRELATION_REQUIRED", "rpc_req missing correlationId", sourceSession.clientId),
          true
        );
      }
      return;
    }

    if (sourceSession) {
      const timeout = setTimeout(() => {
        pendingRpc.delete(envelope.correlationId!);

        const timeoutResponse: RpcResponsePayload = {
          ok: false,
          error: hubError("RPC_TIMEOUT", `RPC timeout for ${targetService}.${method}`)
        };

        logger.warn("rpc.timeout", {
          sessionId: sourceSession.sessionId,
          clientId: sourceSession.clientId,
          targetService,
          method,
          correlationId: envelope.correlationId
        });
        enqueueForSession(sourceSession, createRpcResponseEnvelope(envelope, timeoutResponse, sourceSession.clientId), true);
      }, payload.data.timeoutMs);

      pendingRpc.set(envelope.correlationId, {
        fromSessionId: sourceSession.sessionId,
        startedAt: nowEpochMs(),
        timeout
      });
    }

    enqueueForSession(provider, envelope, true);
  }

  function routeRpcResponse(sourceSession: SessionState | null, envelope: HubEnvelope): void {
    if (!envelope.correlationId) {
      return;
    }

    const controlBlock = controlBlockForEnvelope(envelope);
    if (controlBlock) {
      trackControlDrop(sourceSession?.sessionId ?? "control", envelope, controlBlock.message);
      return;
    }

    const parsed = RpcResponsePayloadSchema.safeParse(envelope.payload);
    if (!parsed.success) {
      return;
    }

    const pendingWs = pendingRpc.get(envelope.correlationId);
    if (pendingWs) {
      clearTimeout(pendingWs.timeout);
      pendingRpc.delete(envelope.correlationId);
      const requester = sessions.get(pendingWs.fromSessionId);
      if (requester) {
        enqueueForSession(requester, envelope, true);
      }
      pushRpcLatency(nowEpochMs() - pendingWs.startedAt);
      return;
    }

    const pendingHttp = pendingHttpRpc.get(envelope.correlationId);
    if (pendingHttp) {
      clearTimeout(pendingHttp.timeout);
      pendingHttpRpc.delete(envelope.correlationId);
      pendingHttp.resolve(parsed.data);
      pushRpcLatency(nowEpochMs() - pendingHttp.startedAt);
      return;
    }

    if (sourceSession && config.logging.routeDebug) {
      logger.debug("rpc.res.unmatched", {
        sessionId: sourceSession.sessionId,
        correlationId: envelope.correlationId
      });
    }
  }

  function handleHubRpc(
    sourceSession: SessionState | null,
    envelope: HubEnvelope,
    method: string,
    payload: RpcRequestPayload
  ): void {
    const respond = (responsePayload: RpcResponsePayload): void => {
      if (sourceSession) {
        enqueueForSession(sourceSession, createRpcResponseEnvelope(envelope, responsePayload, sourceSession.clientId), true);
        return;
      }

      if (!envelope.correlationId) {
        return;
      }

      const pending = pendingHttpRpc.get(envelope.correlationId);
      if (!pending) {
        return;
      }

      clearTimeout(pending.timeout);
      pendingHttpRpc.delete(envelope.correlationId);
      pending.resolve(responsePayload);
    };

    switch (method) {
      case "state_get": {
        const path = (payload.args as { path?: string })?.path;
        if (!path) {
          respond({
            ok: false,
            error: hubError("INVALID_ARGS", "state_get requires args.path")
          });
          return;
        }
        respond({
          ok: true,
          result: stateStore.get(path)
        });
        return;
      }
      default:
        respond({
          ok: false,
          error: hubError("METHOD_NOT_FOUND", `Unknown hub rpc method: ${method}`)
        });
    }
  }

  function broadcastStatePatch(path: string, value: unknown, source: HubEnvelope["source"]): void {
    const envelope = createEnvelope({
      type: "state_patch",
      name: "state.patch",
      source,
      target: "*",
      schemaVersion: 1,
      payload: {
        path,
        value
      }
    });

    if (controlState.stateBroadcastPaused) {
      trackControlDrop("control", envelope, "state broadcast paused");
      return;
    }

    const controlBlock = controlBlockForEnvelope(envelope);
    if (controlBlock) {
      trackControlDrop("control", envelope, controlBlock.message);
      return;
    }

    const recipients: SessionState[] = [];
    for (const session of sessions.values()) {
      if (!matchesStateWatch(session, path)) {
        continue;
      }
      recipients.push(session);
    }

    if (recipients.length === 0) {
      return;
    }

    const prepared = recipients.length > 1 ? prepareEnvelopeForSend(envelope) : null;
    for (const recipient of recipients) {
      enqueueForSession(recipient, envelope, false, prepared);
    }
  }

  function enqueueForSession(
    session: SessionState,
    envelope: HubEnvelope,
    critical: boolean,
    prepared: PreparedEnvelope | null = null
  ): void {
    if (session.socket.readyState !== WebSocket.OPEN) {
      return;
    }

    const outbound = prepared ?? prepareEnvelopeForSend(envelope);
    const { raw, bytes, shouldTrack } = outbound;
    if (bytes > config.limits.maxMessageSizeBytes) {
      metrics.droppedMessages += 1;
      logger.warn("ws.outbound_too_large", {
        sessionId: session.sessionId,
        clientId: session.clientId,
        bytes,
        max: config.limits.maxMessageSizeBytes,
        name: envelope.name
      });
      if (shouldTrack) {
        pushInspector("drop", session.sessionId, envelope, "message too large outbound");
      }
      return;
    }

    const shouldQueue = session.queue.length > 0 || session.socket.bufferedAmount > config.limits.maxSessionBufferedBytes / 2;

    if (!shouldQueue) {
      try {
        session.socket.send(raw);
        metrics.bytesOut += bytes;
        if (shouldTrack) {
          metrics.messagesOut[envelope.type] += 1;
          pushInspector("out", session.sessionId, envelope);
        }
        return;
      } catch {
        // Fall through to queue.
      }
    }

    const item: SessionQueueItem = {
      raw,
      envelope,
      bytes,
      critical
    };

    const decision = applyBackpressure(
      {
        queue: session.queue,
        queueBytes: session.queueBytes
      },
      item,
      {
        maxMessages: config.limits.maxSessionBufferMessages,
        maxBytes: config.limits.maxSessionBufferedBytes
      }
    );

    for (const dropped of decision.dropped) {
      metrics.droppedMessages += 1;
      if (shouldTrackInternalEnvelope(dropped.envelope)) {
        pushInspector("drop", session.sessionId, dropped.envelope, "buffer backpressure");
      }
    }

    session.queueBytes = decision.queueBytes;

    if (!decision.accepted || decision.rejectedCritical) {
      logger.warn("ws.backpressure.reject", {
        sessionId: session.sessionId,
        clientId: session.clientId,
        critical,
        dropped: decision.dropped.length,
        queueBytes: session.queueBytes
      });
      const criticalError = errorEnvelope(
        "BACKPRESSURE",
        "Unable to deliver critical message due to backpressure",
        session.clientId,
        { sessionId: session.sessionId }
      );
      try {
        session.socket.send(JSON.stringify(criticalError));
      } catch {
        // Ignore final fallback errors.
      }
      return;
    }

    queuedSessionIds.add(session.sessionId);
  }

  function flushSessionQueue(session: SessionState): void {
    if (session.socket.readyState !== WebSocket.OPEN) {
      return;
    }

    while (session.queue.length > 0 && session.socket.bufferedAmount < config.limits.maxSessionBufferedBytes / 2) {
      const item = session.queue.shift()!;
      session.queueBytes -= item.bytes;
      try {
        session.socket.send(item.raw);
        metrics.bytesOut += item.bytes;
        if (shouldTrackInternalEnvelope(item.envelope)) {
          metrics.messagesOut[item.envelope.type] += 1;
          pushInspector("out", session.sessionId, item.envelope);
        }
      } catch {
        logger.warn("ws.queue_send_failure", {
          sessionId: session.sessionId,
          clientId: session.clientId,
          name: item.envelope.name
        });
        metrics.droppedMessages += 1;
        if (shouldTrackInternalEnvelope(item.envelope)) {
          pushInspector("drop", session.sessionId, item.envelope, "socket send failure");
        }
      }
    }
  }

  function onSessionClosed(sessionId: string): void {
    const session = sessions.get(sessionId);
    if (!session) {
      return;
    }

    sessions.delete(sessionId);
    queuedSessionIds.delete(sessionId);
    detachSessionFromIndexes(session);

    if (session.serviceName) {
      const key = `${session.serviceName}::${session.instanceId}`;
      const record = presenceByServiceInstance.get(key);
      if (record) {
        record.online = false;
        record.lastSeenTs = nowEpochMs();
        record.sessionId = session.sessionId;
        presenceByServiceInstance.set(key, record);
        persistence.upsertPresence(record);
      }
    }

    logger.info("ws.disconnected", {
      sessionId: session.sessionId,
      clientId: session.clientId,
      serviceName: session.serviceName
    });
  }

  function findSessionsByClientId(clientId: string): SessionState[] {
    const sessionIds = sessionIdsByClient.get(clientId);
    if (!sessionIds) {
      return [];
    }
    return Array.from(sessionIds)
      .map((id) => sessions.get(id))
      .filter((session): session is SessionState => Boolean(session));
  }

  function clearSessionQueue(session: SessionState): { messages: number; bytes: number } {
    const messages = session.queue.length;
    const bytes = session.queueBytes;
    if (messages === 0 && bytes === 0) {
      queuedSessionIds.delete(session.sessionId);
      return { messages: 0, bytes: 0 };
    }

    session.queue.length = 0;
    session.queueBytes = 0;
    queuedSessionIds.delete(session.sessionId);
    return { messages, bytes };
  }

  function detachSessionFromIndexes(session: SessionState): void {
    const byClient = sessionIdsByClient.get(session.clientId);
    if (byClient) {
      byClient.delete(session.sessionId);
      if (byClient.size === 0) {
        sessionIdsByClient.delete(session.clientId);
      }
    }

    if (session.serviceName) {
      const providers = providerSessionIds.get(session.serviceName);
      if (providers) {
        providers.delete(session.sessionId);
        if (providers.size === 0) {
          providerSessionIds.delete(session.serviceName);
          roundRobinCursor.delete(session.serviceName);
        }
      }
    }
  }

  function resolveRecipientsForPublish(envelope: HubEnvelope, excludeSessionId?: string): SessionState[] {
    if (envelope.target === "*") {
      const recipients = Array.from(sessions.values()).filter((session) => {
        if (session.sessionId === excludeSessionId) {
          return false;
        }
        return matchesSubscription(session, envelope.name);
      });
      return recipients;
    }

    if (envelope.target.clientId) {
      const sessionIds = sessionIdsByClient.get(envelope.target.clientId);
      if (!sessionIds) {
        return [];
      }
      return Array.from(sessionIds)
        .map((id) => sessions.get(id))
        .filter((session): session is SessionState => Boolean(session && session.sessionId !== excludeSessionId));
    }

    if (envelope.target.serviceName) {
      const sessionIds = providerSessionIds.get(envelope.target.serviceName);
      if (!sessionIds) {
        return [];
      }
      return Array.from(sessionIds)
        .map((id) => sessions.get(id))
        .filter((session): session is SessionState => Boolean(session && session.sessionId !== excludeSessionId));
    }

    return [];
  }

  function pickProviderSession(serviceName: string): SessionState | null {
    const providerIds = providerSessionIds.get(serviceName);
    if (!providerIds || providerIds.size === 0) {
      return null;
    }

    const online = Array.from(providerIds)
      .map((id) => sessions.get(id))
      .filter((session): session is SessionState => Boolean(session));

    if (online.length === 0) {
      return null;
    }

    const cursor = roundRobinCursor.get(serviceName) ?? 0;
    const selected = online[cursor % online.length];
    roundRobinCursor.set(serviceName, (cursor + 1) % online.length);
    return selected;
  }

  function createEnvelope(input: {
    type: HubMessageType;
    name: string;
    source: HubEnvelope["source"];
    target: HubTarget;
    payload: unknown;
    schemaVersion: number;
    correlationId?: string;
  }): HubEnvelope {
    return {
      v: 1,
      id: randomUUID(),
      type: input.type,
      name: input.name,
      source: input.source,
      target: input.target,
      ts: nowEpochMs(),
      correlationId: input.correlationId,
      schemaVersion: input.schemaVersion,
      payload: input.payload
    };
  }

  function createRpcResponseEnvelope(request: HubEnvelope, payload: RpcResponsePayload, targetClientId: string): HubEnvelope {
    return createEnvelope({
      type: "rpc_res",
      name: request.name,
      source: {
        clientId: "hub",
        serviceName: "hub"
      },
      target: {
        clientId: targetClientId
      },
      schemaVersion: 1,
      correlationId: request.correlationId,
      payload
    });
  }

  function errorEnvelope(
    code: string,
    message: string,
    clientId: string | null,
    details?: unknown,
    correlationId?: string
  ): HubEnvelope {
    return createEnvelope({
      type: "error",
      name: "error",
      source: {
        clientId: "hub",
        serviceName: "hub"
      },
      target: clientId ? { clientId } : "*",
      schemaVersion: 1,
      correlationId,
      payload: hubError(code, message, details)
    });
  }

  function pushInspector(direction: Direction, sessionId: string, envelope: HubEnvelope, reason?: string): void {
    inspector.push({
      ts: nowEpochMs(),
      direction,
      sessionId,
      envelope,
      reason
    });

    if (inspector.length > config.limits.inspectorMaxMessages) {
      inspector.splice(0, inspector.length - config.limits.inspectorMaxMessages);
    }
  }

  function bumpTopic(name: string): void {
    messageNameCounter.set(name, (messageNameCounter.get(name) ?? 0) + 1);
  }

  function incrementSessionRate(session: SessionState): boolean {
    const limitPerMinute = config.limits.rateLimitPerMinute;
    if (limitPerMinute <= 0) {
      return true;
    }

    const now = nowEpochMs();
    const elapsedMs = Math.max(0, now - session.rateLastRefillTs);
    if (elapsedMs > 0) {
      const refill = (limitPerMinute * elapsedMs) / 60000;
      session.rateTokens = Math.min(limitPerMinute, session.rateTokens + refill);
      session.rateLastRefillTs = now;
    }

    if (session.rateTokens < 1) {
      return false;
    }

    session.rateTokens -= 1;
    return true;
  }

  function isDuplicateMessage(session: SessionState, messageId: string): boolean {
    const now = nowEpochMs();

    if (now - session.lastDedupSweepTs >= DEDUP_SWEEP_INTERVAL_MS) {
      for (const [id, ts] of session.recentIds.entries()) {
        if (now - ts > config.limits.dedupWindowMs) {
          session.recentIds.delete(id);
        }
      }
      session.lastDedupSweepTs = now;
    }

    if (session.recentIds.has(messageId)) {
      return true;
    }

    session.recentIds.set(messageId, now);
    return false;
  }

  function matchesSubscription(session: SessionState, messageName: string): boolean {
    if (session.subscriptions.size === 0) {
      return false;
    }

    for (const subscription of session.subscriptions.values()) {
      if (subscription.names?.includes(messageName)) {
        return true;
      }
      if (subscription.namePrefix && messageName.startsWith(subscription.namePrefix)) {
        return true;
      }
    }

    return false;
  }

  function matchesStateWatch(session: SessionState, statePath: string): boolean {
    if (session.stateWatches.size === 0) {
      return false;
    }

    for (const prefix of session.stateWatches.values()) {
      if (statePath.startsWith(prefix)) {
        return true;
      }
    }

    return false;
  }

  function controlBlockForEnvelope(envelope: HubEnvelope): ControlBlock | null {
    const sourceService = envelope.source.serviceName;
    if (sourceService && sourceService !== "hub" && controlState.mutedServices.has(sourceService)) {
      return {
        code: "MUTED_SERVICE",
        message: `Service ${sourceService} is muted`,
        details: { serviceName: sourceService, direction: "source" }
      };
    }

    if (envelope.target !== "*" && envelope.target.serviceName && controlState.mutedServices.has(envelope.target.serviceName)) {
      return {
        code: "MUTED_SERVICE",
        message: `Service ${envelope.target.serviceName} is muted`,
        details: { serviceName: envelope.target.serviceName, direction: "target" }
      };
    }

    const mutedPattern = findMutedTopicPattern(envelope.name);
    if (mutedPattern) {
      return {
        code: "MUTED_TOPIC",
        message: `Topic ${envelope.name} is muted`,
        details: { topic: envelope.name, pattern: mutedPattern }
      };
    }

    return null;
  }

  function findMutedTopicPattern(topicName: string): string | null {
    for (const pattern of controlState.mutedTopics.values()) {
      if (pattern.endsWith("*")) {
        const prefix = pattern.slice(0, -1);
        if (topicName.startsWith(prefix)) {
          return pattern;
        }
        continue;
      }

      if (topicName === pattern) {
        return pattern;
      }
    }

    return null;
  }

  function trackControlDrop(sessionId: string, envelope: HubEnvelope, reason: string): void {
    metrics.droppedMessages += 1;
    if (shouldTrackInternalEnvelope(envelope)) {
      pushInspector("drop", sessionId, envelope, reason);
    }
  }

  function shouldTrackInternalEnvelope(envelope: HubEnvelope): boolean {
    return envelope.name !== DASHBOARD_STREAM_EVENT_NAME;
  }

  function prepareEnvelopeForSend(envelope: HubEnvelope): PreparedEnvelope {
    const raw = JSON.stringify(envelope);
    return {
      raw,
      bytes: Buffer.byteLength(raw, "utf8"),
      shouldTrack: shouldTrackInternalEnvelope(envelope)
    };
  }

  function pushRpcLatency(latencyMs: number): void {
    metrics.rpcLatenciesMs.push(latencyMs);
    if (metrics.rpcLatenciesMs.length > 5000) {
      metrics.rpcLatenciesMs.splice(0, metrics.rpcLatenciesMs.length - 5000);
    }
  }

  function closeAllSessions(): void {
    for (const session of sessions.values()) {
      session.socket.close(1001, "Hub shutdown");
    }
    sessions.clear();
    queuedSessionIds.clear();
  }

  const runtime: HubRuntime = {
    app,
    close: async () => {
      closeAllSessions();
      await app.close();
    }
  };

  return runtime;
}

function extractServiceTarget(target: HubTarget): string | null {
  if (target === "*") {
    return null;
  }
  return target.serviceName ?? null;
}

function isHubTarget(target: HubTarget): boolean {
  if (target === "*") {
    return false;
  }

  return target.serviceName === "hub";
}

function normalizeStatePath(path: string): string {
  if (path.startsWith("state/")) {
    return path;
  }
  return `state/${path.replace(/^\/+/, "")}`;
}

function pathExists(pathToCheck: string): boolean {
  return fs.existsSync(pathToCheck);
}

function serveStaticFromDir(
  reply: FastifyReply,
  rootDir: string,
  wildcardPath: string,
  defaultFile: string
): boolean {
  const resolvedRoot = path.resolve(rootDir);
  const relativePathRaw = wildcardPath || "";
  const relativePathDecoded = decodeURIComponent(relativePathRaw);
  let relativePath = relativePathDecoded;

  if (!relativePath || relativePath.endsWith("/")) {
    relativePath = `${relativePath}${defaultFile}`;
  }

  relativePath = relativePath.replace(/^\/+/, "");
  const resolvedFile = path.resolve(resolvedRoot, relativePath);

  if (!isPathWithinRoot(resolvedRoot, resolvedFile)) {
    reply.code(403).send({ error: hubError("FORBIDDEN", "Invalid static asset path") });
    return true;
  }

  if (!pathExists(resolvedFile)) {
    return false;
  }

  let finalFile = resolvedFile;
  const stat = fs.statSync(finalFile);
  if (stat.isDirectory()) {
    finalFile = path.join(finalFile, defaultFile);
  }

  if (!pathExists(finalFile)) {
    return false;
  }

  const body = fs.readFileSync(finalFile);
  reply.header("Cache-Control", "no-store");
  reply.type(contentTypeForFile(finalFile));
  reply.send(body);
  return true;
}

function isPathWithinRoot(rootDir: string, filePath: string): boolean {
  const normalizedRoot = rootDir.endsWith(path.sep) ? rootDir : `${rootDir}${path.sep}`;
  return filePath === rootDir || filePath.startsWith(normalizedRoot);
}

function isCorsOriginAllowed(origin: string, configuredOrigins: string[]): boolean {
  if (configuredOrigins.includes(origin)) {
    return true;
  }

  let parsed: URL;
  try {
    parsed = new URL(origin);
  } catch {
    return false;
  }

  const hostname = parsed.hostname.toLowerCase();
  if (hostname === "localhost" || hostname === "127.0.0.1" || hostname === "::1") {
    return true;
  }

  return false;
}

function contentTypeForFile(filePath: string): string {
  switch (path.extname(filePath).toLowerCase()) {
    case ".html":
      return "text/html; charset=utf-8";
    case ".css":
      return "text/css; charset=utf-8";
    case ".js":
      return "application/javascript; charset=utf-8";
    case ".json":
      return "application/json; charset=utf-8";
    case ".svg":
      return "image/svg+xml";
    case ".png":
      return "image/png";
    case ".jpg":
    case ".jpeg":
      return "image/jpeg";
    case ".woff":
      return "font/woff";
    case ".woff2":
      return "font/woff2";
    default:
      return "application/octet-stream";
  }
}

function payloadForContractValidation(envelope: HubEnvelope): { shouldValidate: boolean; payload: unknown } {
  if (envelope.type === "rpc_req") {
    const payload = envelope.payload as { args?: unknown } | null;
    return {
      shouldValidate: true,
      payload: payload?.args
    };
  }

  if (envelope.type === "rpc_res" || envelope.type === "presence" || envelope.type === "error") {
    return {
      shouldValidate: false,
      payload: envelope.payload
    };
  }

  return {
    shouldValidate: true,
    payload: envelope.payload
  };
}

async function generateQrDataUrl(content: string): Promise<string | null> {
  const moduleName = "qrcode";
  try {
    const qrcodeModule = (await import(moduleName)) as {
      toDataURL: (value: string, options?: Record<string, unknown>) => Promise<string>;
    };
    return await qrcodeModule.toDataURL(content, {
      errorCorrectionLevel: "M",
      margin: 1,
      width: 280
    });
  } catch {
    return null;
  }
}

function percentile(sortedValues: number[], percentileValue: number): number {
  if (sortedValues.length === 0) {
    return 0;
  }

  const index = Math.min(
    sortedValues.length - 1,
    Math.max(0, Math.floor((percentileValue / 100) * sortedValues.length) - 1)
  );

  return sortedValues[index] ?? 0;
}

function escapeHtml(input: string): string {
  return input
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}
